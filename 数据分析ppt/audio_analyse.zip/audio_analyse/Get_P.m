function [P]= Get_P(y)
y = abs(y);
y = y.^2;
P = sum(y,1);
end