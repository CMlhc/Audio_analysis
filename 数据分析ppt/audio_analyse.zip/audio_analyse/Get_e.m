function [e]=Get_e(t,fre)
e=zeros(513,360,6);
for i=1:513
   for j=1:360
      for k=1:6
        e(i,j,k)=  exp(1j*fre(i)*t(j,k));
      end 
   end    
end
