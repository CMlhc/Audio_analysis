%dΪÿ�εļ��
function [multiple] = multiple_sound(y, fre,G)
    for i = 1:6:513
        if (i+11<=513)
            l = i;
            r = i+11;
            P=Get_M_P(y,l,r);
            [no, angle] = max(P);
            G(angle) = G(angle) + 1;
        else
            l = i;
            r = 513;
            P=Get_M_P(y,l,r);
            [no, angle] = max(P);
            G(angle) = G(angle) + 1;
        end
    end
    multiple = G;
end
            
            





         
        