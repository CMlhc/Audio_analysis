function [y] = RESULT(G,X,t,fre,e)
y = zeros(513,360);
G=1./G;
M=zeros(513,6);
for i=1:360
 M=permute(e(:,i,:),[1 3 2]);
T=G.*M.*X; 
y(:,i)=sum(T,2);   
 end
  