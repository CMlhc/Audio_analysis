function [mul] = check_multi(g,z,u)
res = zeros(360,1);
while(1)
    [c,m] = max(g);
    if c>z
        res(m) = m;
        if m-u >0
            g(m-u:m+u) = 0;
        else
            g(1:m+u) = 0;
        end
        z = max(c/2,z);
    else
        break;
    end
end
mul = res;
        
        